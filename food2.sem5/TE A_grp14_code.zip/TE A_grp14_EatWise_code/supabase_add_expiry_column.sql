-- Run this in Supabase SQL Editor if you get "Could not find the 'expiry_date' column" error.
-- This adds the missing column to your existing products table.

alter table public.products
  add column if not exists expiry_date timestamptz;

-- If your table has different column names, you might need to add other columns too.
-- Standard columns expected by the app: id, user_id, product_name, barcode, expiry_date, created_at
