package com.example.ai_food_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
