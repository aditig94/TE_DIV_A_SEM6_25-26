import 'package:supabase_flutter/supabase_flutter.dart';

/// Products are stored in Supabase table `products`.
/// Run the SQL in supabase_products_setup.sql in your Supabase SQL Editor once.
class ProductsService {
  static SupabaseClient get _client => Supabase.instance.client;

  static String? get _userId => _client.auth.currentUser?.id;

  /// Fetch all products for the current user.
  static Future<List<Map<String, dynamic>>> getProducts() async {
    final uid = _userId;
    if (uid == null) return [];

    final res = await _client
        .from('products')
        .select()
        .eq('user_id', uid)
        .order('expiry_date', ascending: true);

    final list = List<Map<String, dynamic>>.from(res as List);
    // Normalize to app format (expiryDate string for compatibility)
    return list.map((row) {
      final expiry = row['expiry_date'];
      return {
        'id': row['id'],
        'product_name': row['product_name'],
        'barcode': row['barcode'] ?? '',
        'expiryDate': expiry != null ? expiry.toString() : null,
      };
    }).toList();
  }

  /// Insert a product for the current user.
  /// [productName] required; [barcode] and [expiryDate] optional.
  static Future<void> addProduct({
    required String productName,
    String? barcode,
    DateTime? expiryDate,
  }) async {
    final uid = _userId;
    if (uid == null) {
      throw Exception('You must be logged in to add products.');
    }

    await _client.from('products').insert({
      'user_id': uid,
      'product_name': productName,
      'barcode': barcode ?? '',
      'expiry_date': expiryDate?.toIso8601String(),
    });
  }

  /// Delete a product by id.
  static Future<void> deleteProduct(String id) async {
    final uid = _userId;
    if (uid == null) return;

    await _client.from('products').delete().eq('id', id).eq('user_id', uid);
  }
}
