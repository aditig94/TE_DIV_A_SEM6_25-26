import 'package:supabase_flutter/supabase_flutter.dart';

/// Fetches and updates user profile from the `profiles` table.
/// Run supabase_profiles_setup.sql in Supabase SQL Editor once.
class ProfileService {
  static SupabaseClient get _client => Supabase.instance.client;

  static String? get _userId => _client.auth.currentUser?.id;

  /// Profile row from DB (nullable fields for compatibility).
  static Future<Map<String, dynamic>?> getProfile() async {
    final uid = _userId;
    if (uid == null) return null;

    try {
      final res = await _client
          .from('profiles')
          .select()
          .eq('id', uid)
          .maybeSingle();
      return res == null ? null : Map<String, dynamic>.from(res as Map);
    } catch (_) {
      return null;
    }
  }

  /// Insert profile row (call after signup). Id must match auth.users.id.
  static Future<void> insertProfile({
    required String id,
    String? fullName,
    String? goal,
    String? allergies,
    int? calorieTarget,
  }) async {
    await _client.from('profiles').insert({
      'id': id,
      'full_name': fullName,
      'goal': goal,
      'allergies': allergies,
      'calorie_target': calorieTarget ?? 2000,
    });
  }

  /// Update profile fields. Only provided non-null fields are updated.
  static Future<void> updateProfile({
    String? fullName,
    String? goal,
    String? allergies,
    int? calorieTarget,
  }) async {
    final uid = _userId;
    if (uid == null) return;

    final Map<String, dynamic> updates = {};
    if (fullName != null) updates['full_name'] = fullName;
    if (goal != null) updates['goal'] = goal;
    if (allergies != null) updates['allergies'] = allergies;
    if (calorieTarget != null) updates['calorie_target'] = calorieTarget;
    if (updates.isEmpty) return;

    await _client.from('profiles').update(updates).eq('id', uid);
  }
}
