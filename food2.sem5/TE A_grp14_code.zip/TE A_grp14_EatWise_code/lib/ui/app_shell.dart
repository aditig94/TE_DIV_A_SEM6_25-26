import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../widgets/chatbot_widget.dart';

class AppShell extends StatelessWidget {
  final Widget child;

  const AppShell({super.key, required this.child});

  void _goDashboard(BuildContext context) {
    Navigator.pushReplacementNamed(context, '/home');
  }

  void _goProfile(BuildContext context) {
    Navigator.pushNamed(context, '/profile');
  }

  Future<void> _logout(BuildContext context) async {
    await Supabase.instance.client.auth.signOut();
    if (context.mounted) {
      Navigator.pushReplacementNamed(context, '/auth');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              children: [
                Container(
                  height: 70,
                  decoration: const BoxDecoration(
                    color: Color(0xFF020617),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black54,
                        blurRadius: 22,
                        spreadRadius: -10,
                        offset: Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1100),
                        child: Row(
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 30,
                                  height: 30,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(
                                      colors: [
                                        Color(0xFF22D3EE),
                                        Color(0xFFA855F7),
                                      ],
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.eco,
                                    size: 18,
                                    color: Colors.black,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  'EatWise',
                                  style: GoogleFonts.spaceGrotesk(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                            const Spacer(),
                            _navButton(
                              context,
                              label: 'Dashboard',
                              onTap: () => _goDashboard(context),
                            ),
                            const SizedBox(width: 12),
                            _navButton(
                              context,
                              label: 'Profile',
                              onTap: () => _goProfile(context),
                            ),
                            const SizedBox(width: 12),
                            _navButton(
                              context,
                              label: 'Logout',
                              onTap: () => _logout(context),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 24,
                      ),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1100),
                        child: child,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const ChatbotWidget(),
        ],
      ),
    );
  }

  Widget _navButton(
    BuildContext context, {
    required String label,
    required VoidCallback onTap,
  }) {
    return TextButton(
      onPressed: onTap,
      child: Text(
        label,
        style: GoogleFonts.poppins(
          color: Colors.white70,
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

