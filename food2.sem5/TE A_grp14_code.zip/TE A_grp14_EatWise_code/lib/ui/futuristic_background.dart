import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import 'futuristic_theme.dart';

class FuturisticBackground extends StatefulWidget {
  const FuturisticBackground({super.key});

  @override
  State<FuturisticBackground> createState() => _FuturisticBackgroundState();
}

class _FuturisticBackgroundState extends State<FuturisticBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final ValueNotifier<Offset> _pointerOffset =
      ValueNotifier<Offset>(Offset.zero);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    _pointerOffset.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onHover: (e) {
        final size = MediaQuery.of(context).size;
        final center = size.center(Offset.zero);
        final delta = (e.position - center) / size.shortestSide;
        _pointerOffset.value = Offset(delta.dx.clamp(-1.0, 1.0),
            delta.dy.clamp(-1.0, 1.0));
      },
      onExit: (_) => _pointerOffset.value = Offset.zero,
      child: ValueListenableBuilder<Offset>(
        valueListenable: _pointerOffset,
        builder: (context, parallax, _) {
          return AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final t = _controller.value;
              return Stack(
                fit: StackFit.expand,
                children: [
                  // Deep gradient base
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 800),
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(-0.2 + parallax.dx * 0.2,
                            -0.4 + parallax.dy * 0.2),
                        radius: 1.4,
                        colors: [
                          FuturisticColors.background,
                          FuturisticColors.backgroundSecondary,
                          const Color(0xFF03030A),
                        ],
                        stops: const [0.0, 0.6, 1.0],
                      ),
                    ),
                  ),

                  // Moving gradient blobs
                  _AnimatedBlobLayer(
                    t: t,
                    parallax: parallax,
                    baseColor: FuturisticColors.accentCyan.withOpacity(0.28),
                    offsetMultiplier: const Offset(-40, -20),
                    size: 520,
                  ),
                  _AnimatedBlobLayer(
                    t: t + 0.33,
                    parallax: parallax,
                    baseColor: FuturisticColors.accentPurple.withOpacity(0.24),
                    offsetMultiplier: const Offset(60, 40),
                    size: 480,
                  ),
                  _AnimatedBlobLayer(
                    t: t + 0.66,
                    parallax: parallax,
                    baseColor: FuturisticColors.accentPink.withOpacity(0.20),
                    offsetMultiplier: const Offset(-10, 80),
                    size: 420,
                  ),

                  // Glass veil
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
                    child: Container(
                      color: Colors.white.withOpacity(0.02),
                    ),
                  ),

                  // Neon particles
                  CustomPaint(
                    painter: _ParticlePainter(
                      t: t,
                      parallax: parallax,
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _AnimatedBlobLayer extends StatelessWidget {
  final double t;
  final Offset parallax;
  final Color baseColor;
  final Offset offsetMultiplier;
  final double size;

  const _AnimatedBlobLayer({
    required this.t,
    required this.parallax,
    required this.baseColor,
    required this.offsetMultiplier,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    final eased = Curves.easeInOutSine.transform(t % 1.0);
    final dx = sin(eased * 2 * pi) * offsetMultiplier.dx +
        parallax.dx * offsetMultiplier.dx * 0.4;
    final dy = cos(eased * 2 * pi) * offsetMultiplier.dy +
        parallax.dy * offsetMultiplier.dy * 0.4;

    return Transform.translate(
      offset: Offset(dx, dy),
      child: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [
              baseColor,
              Colors.transparent,
            ],
          ),
        ),
      ),
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final double t;
  final Offset parallax;
  final int count = 60;

  _ParticlePainter({
    required this.t,
    required this.parallax,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final random = Random(7);

    for (var i = 0; i < count; i++) {
      final seed = random.nextDouble();
      final orbitRadius = size.shortestSide * (0.15 + seed * 0.6);
      final speed = 0.4 + seed * 1.2;
      final angle = (t * speed + seed * pi * 2);

      final baseX = size.width / 2 + cos(angle) * orbitRadius;
      final baseY = size.height / 2 + sin(angle) * orbitRadius * 0.7;

      final depth = 0.4 + seed * 0.6;
      final px = baseX + parallax.dx * 40 * depth;
      final py = baseY + parallax.dy * 30 * depth;

      final radius = 1.5 + seed * 3.5;
      final glowColor = Color.lerp(
        FuturisticColors.accentCyan,
        FuturisticColors.accentPurple,
        seed,
      )!
          .withOpacity(0.4 + 0.4 * depth);

      // Outer glow
      final glowPaint = Paint()
        ..color = glowColor
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(Offset(px, py), radius * 2.5, glowPaint);

      // Core
      paint.color = Colors.white.withOpacity(0.9);
      canvas.drawCircle(Offset(px, py), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) {
    return oldDelegate.t != t || oldDelegate.parallax != parallax;
  }
}

