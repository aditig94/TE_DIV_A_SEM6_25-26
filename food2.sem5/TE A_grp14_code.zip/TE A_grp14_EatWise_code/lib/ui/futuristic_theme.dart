import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FuturisticColors {
  static const Color background = Color(0xFF050814);
  static const Color backgroundSecondary = Color(0xFF050A1F);
  static const Color accentCyan = Color(0xFF4DF2FF);
  static const Color accentPurple = Color(0xFFB264FF);
  static const Color accentPink = Color(0xFFFF5FA2);
  static const Color surface = Color(0x33FFFFFF);
  static const Color surfaceStrong = Color(0x66FFFFFF);
}

class FuturisticTextStyles {
  static TextStyle displayLarge(BuildContext context) =>
      GoogleFonts.montserrat(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.4,
        color: Colors.white,
      );

  static TextStyle displayMedium(BuildContext context) =>
      GoogleFonts.montserrat(
        fontSize: 24,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.3,
        color: Colors.white,
      );

  static TextStyle subtitle(BuildContext context) =>
      GoogleFonts.poppins(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.2,
        color: Colors.white70,
      );

  static TextStyle body(BuildContext context) =>
      GoogleFonts.poppins(
        fontSize: 13,
        fontWeight: FontWeight.w400,
        color: Colors.white70,
      );

  static TextStyle chip(BuildContext context) =>
      GoogleFonts.poppins(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.5,
        color: Colors.white,
      );
}

ThemeData buildFuturisticTheme() {
  final base = ThemeData.dark();
  return base.copyWith(
    scaffoldBackgroundColor: FuturisticColors.background,
    colorScheme: base.colorScheme.copyWith(
      primary: FuturisticColors.accentCyan,
      secondary: FuturisticColors.accentPurple,
      background: FuturisticColors.background,
      surface: FuturisticColors.surface,
    ),
    textTheme: GoogleFonts.poppinsTextTheme(
      base.textTheme.apply(
        bodyColor: Colors.white,
        displayColor: Colors.white,
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      foregroundColor: Colors.white,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.black,
        backgroundColor: FuturisticColors.accentCyan,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      ),
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor:
          MaterialStateProperty.all(FuturisticColors.accentCyan.withOpacity(0.9)),
      side: const BorderSide(color: Colors.white30, width: 1.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
    ),
    cardColor: FuturisticColors.surface,
  );
}

