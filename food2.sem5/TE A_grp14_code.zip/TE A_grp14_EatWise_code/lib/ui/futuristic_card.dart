import 'dart:ui';

import 'package:flutter/material.dart';

import 'futuristic_theme.dart';

class FuturisticActionCard extends StatefulWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color accentColor;
  final VoidCallback onTap;
  final String heroTag;

  const FuturisticActionCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accentColor,
    required this.onTap,
    required this.heroTag,
  });

  @override
  State<FuturisticActionCard> createState() => _FuturisticActionCardState();
}

class _FuturisticActionCardState extends State<FuturisticActionCard> {
  bool _hovering = false;
  bool _pressed = false;

  void _setHover(bool value) {
    setState(() {
      _hovering = value;
    });
  }

  void _setPressed(bool value) {
    setState(() {
      _pressed = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final depth = _pressed ? 0.96 : (_hovering ? 1.04 : 1.0);
    final slide = _pressed
        ? const Offset(0, 4)
        : (_hovering ? const Offset(0, -4) : Offset.zero);

    return MouseRegion(
      onEnter: (_) => _setHover(true),
      onExit: (_) => _setHover(false),
      child: GestureDetector(
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) {
          _setPressed(false);
          widget.onTap();
        },
        onTapCancel: () => _setPressed(false),
        child: TweenAnimationBuilder<double>(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          tween: Tween<double>(begin: 1.0, end: depth),
          builder: (context, value, child) {
            return Transform.translate(
              offset: slide,
              child: Transform.scale(
                scale: value,
                child: child,
              ),
            );
          },
          child: Hero(
            tag: widget.heroTag,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOutCubic,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(26),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.white.withOpacity(_hovering ? 0.10 : 0.05),
                        Colors.white.withOpacity(_hovering ? 0.03 : 0.01),
                      ],
                    ),
                    border: Border.all(
                      color: widget.accentColor.withOpacity(
                        _hovering ? 0.8 : 0.4,
                      ),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color:
                            widget.accentColor.withOpacity(_hovering ? 0.55 : 0.32),
                        blurRadius: 32,
                        spreadRadius: -12,
                        offset: const Offset(0, 20),
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 40,
                        spreadRadius: -20,
                        offset: const Offset(0, 28),
                      ),
                    ],
                  ),
                  child: _CardContent(
                    icon: widget.icon,
                    title: widget.title,
                    subtitle: widget.subtitle,
                    accentColor: widget.accentColor,
                    hovering: _hovering,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CardContent extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color accentColor;
  final bool hovering;

  const _CardContent({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accentColor,
    required this.hovering,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              _GlowingIcon(
                icon: icon,
                accentColor: accentColor,
                hovering: hovering,
              ),
              const Spacer(),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 220),
                opacity: hovering ? 1 : 0.0,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    gradient: LinearGradient(
                      colors: [
                        accentColor.withOpacity(0.9),
                        FuturisticColors.accentCyan.withOpacity(0.9),
                      ],
                    ),
                  ),
                  child: Text(
                    'Open',
                    style: FuturisticTextStyles.chip(context),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Text(
            title,
            style: FuturisticTextStyles.displayMedium(context).copyWith(
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: FuturisticTextStyles.body(context),
          ),
        ],
      ),
    );
  }
}

class _GlowingIcon extends StatelessWidget {
  final IconData icon;
  final Color accentColor;
  final bool hovering;

  const _GlowingIcon({
    required this.icon,
    required this.accentColor,
    required this.hovering,
  });

  @override
  Widget build(BuildContext context) {
    final baseSize = 52.0;

    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
      tween: Tween<double>(
        begin: 1.0,
        end: hovering ? 1.05 : 1.0,
      ),
      builder: (context, value, child) {
        return Transform.scale(
          scale: value,
          child: child,
        );
      },
      child: Container(
        width: baseSize,
        height: baseSize,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: SweepGradient(
            colors: [
              accentColor.withOpacity(0.15),
              FuturisticColors.accentCyan.withOpacity(0.18),
              FuturisticColors.accentPurple.withOpacity(0.26),
              accentColor.withOpacity(0.15),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: accentColor.withOpacity(0.7),
              blurRadius: hovering ? 28 : 18,
              spreadRadius: hovering ? 2 : 0,
            ),
          ],
        ),
        child: Center(
          child: Icon(
            icon,
            color: Colors.white,
            size: 26,
          ),
        ),
      ),
    );
  }
}

