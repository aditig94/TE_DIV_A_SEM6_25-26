import 'package:flutter/material.dart';

class FuturisticPageRoute<T> extends PageRouteBuilder<T> {
  FuturisticPageRoute({
    required WidgetBuilder builder,
    RouteSettings? settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) =>
              builder(context),
          transitionDuration: const Duration(milliseconds: 520),
          reverseTransitionDuration: const Duration(milliseconds: 380),
          settings: settings,
          transitionsBuilder:
              (context, animation, secondaryAnimation, child) {
            final curved = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
              reverseCurve: Curves.easeInCubic,
            );

            final slideTween =
                Tween<Offset>(begin: const Offset(0.04, 0.02), end: Offset.zero);
            final fadeTween = Tween<double>(begin: 0.0, end: 1.0);
            final scaleTween = Tween<double>(begin: 0.96, end: 1.0);

            return FadeTransition(
              opacity: fadeTween.animate(curved),
              child: SlideTransition(
                position: slideTween.animate(curved),
                child: ScaleTransition(
                  scale: scaleTween.animate(curved),
                  child: child,
                ),
              ),
            );
          },
        );
}

