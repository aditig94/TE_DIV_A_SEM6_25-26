import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/barcode_screen.dart';
import 'screens/recipe_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/edit_profile_screen.dart';
import 'screens/add_product_screen.dart';
import 'screens/landing_screen.dart';
import 'ui/futuristic_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://mbgebzkvxfcugykauccj.supabase.co',
    anonKey:
        'sb_publishable_j_p9j1kTYTf0LwsaPCQHYQ_zNDhz3ag',
  );

  runApp(const EatWiseApp());
}

class EatWiseApp extends StatelessWidget {
  const EatWiseApp({super.key});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;

    return MaterialApp(
      title: 'EatWise',
      debugShowCheckedModeBanner: false,
      theme: buildFuturisticTheme(),

      routes: {
        '/auth': (_) => const AuthScreen(),
        '/home': (_) => const HomeScreen(),
        '/profile': (_) => const ProfileScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/edit_profile': (_) => const EditProfileScreen(),
        '/barcode': (_) => const BarcodeScreen(),
        '/recipe': (_) => const RecipeScreen(),
        '/add_product': (_) => const AddProductScreen(),
      },

      home: supabase.auth.currentUser != null
          ? const HomeScreen()
          : const LandingScreen(),
    );
  }
}