import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/gemini_service.dart';

enum _MessageRole { user, assistant }

class _ChatMessage {
  final _MessageRole role;
  final String text;

  _ChatMessage({required this.role, required this.text});
}

class ChatbotWidget extends StatefulWidget {
  const ChatbotWidget({super.key});

  @override
  State<ChatbotWidget> createState() => _ChatbotWidgetState();
}

class _ChatbotWidgetState extends State<ChatbotWidget> {
  bool _expanded = false;
  final List<_ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _loading = false;
  final GeminiService _geminiService = GeminiService();

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage() async {
    final text = _inputController.text.trim();
    if (text.isEmpty || _loading) return;

    _inputController.clear();
    setState(() {
      _messages.add(_ChatMessage(role: _MessageRole.user, text: text));
      _loading = true;
    });
    _scrollToBottom();

    try {
      final reply = await _geminiService.sendMessage(text);
      if (mounted) {
        setState(() {
          _messages.add(_ChatMessage(role: _MessageRole.assistant, text: reply));
          _loading = false;
        });
        _scrollToBottom();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(
            _ChatMessage(
              role: _MessageRole.assistant,
              text: 'Sorry, something went wrong. Please try again.',
            ),
          );
          _loading = false;
        });
        _scrollToBottom();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isNarrow = MediaQuery.sizeOf(context).width < 600;
    final expandedWidth = isNarrow ? MediaQuery.sizeOf(context).width * 0.9 : 350.0;
    final expandedHeight = isNarrow ? MediaQuery.sizeOf(context).height * 0.7 : 500.0;

    return Positioned(
      bottom: 20,
      right: 20,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        width: _expanded ? expandedWidth : 60,
        height: _expanded ? expandedHeight : 60,
        decoration: BoxDecoration(
          color: _expanded ? const Color(0xFF0F172A) : const Color(0xFF020617),
          borderRadius: BorderRadius.circular(_expanded ? 20 : 30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: _expanded ? 24 : 12,
              spreadRadius: _expanded ? -4 : 0,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: _expanded ? _buildExpandedPanel(context) : _buildCollapsedButton(context),
      ),
    );
  }

  Widget _buildCollapsedButton(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => setState(() => _expanded = true),
        borderRadius: BorderRadius.circular(30),
        child: const Center(
          child: Icon(
            Icons.smart_toy_outlined,
            color: Color(0xFF22D3EE),
            size: 28,
          ),
        ),
      ),
    );
  }

  Widget _buildExpandedPanel(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildHeader(context),
          Expanded(
            child: _buildMessagesArea(context),
          ),
          _buildInputArea(context),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        color: Color(0xFF020617),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.smart_toy_outlined,
            color: Color(0xFF22D3EE),
            size: 22,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'AI Nutrition Assistant',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          IconButton(
            onPressed: () => setState(() => _expanded = false),
            icon: const Icon(Icons.close, color: Colors.white70, size: 22),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
          ),
        ],
      ),
    );
  }

  Widget _buildMessagesArea(BuildContext context) {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: _messages.length + (_loading ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == _messages.length) {
          return Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 16),
            child: Row(
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      const Color(0xFF22D3EE).withOpacity(0.9),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Thinking...',
                  style: GoogleFonts.poppins(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          );
        }
        final msg = _messages[index];
        return _MessageBubble(role: msg.role, text: msg.text);
      },
    );
  }

  Widget _buildInputArea(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF020617).withOpacity(0.95),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _inputController,
              enabled: !_loading,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Ask about nutrition...',
                hintStyle: GoogleFonts.poppins(color: Colors.white38, fontSize: 13),
                filled: true,
                fillColor: const Color(0xFF0F172A),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF1F2937)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF22D3EE), width: 1),
                ),
              ),
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          const SizedBox(width: 8),
          Material(
            color: const Color(0xFF22D3EE).withOpacity(0.9),
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              onTap: _loading ? null : _sendMessage,
              borderRadius: BorderRadius.circular(12),
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Icon(Icons.send_rounded, color: Colors.black87, size: 22),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final _MessageRole role;
  final String text;

  const _MessageBubble({required this.role, required this.text});

  @override
  Widget build(BuildContext context) {
    final isUser = role == _MessageRole.user;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) const SizedBox(width: 4),
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? const Color(0xFF22D3EE).withOpacity(0.2)
                    : const Color(0xFF1F2937),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
                border: Border.all(
                  color: isUser
                      ? const Color(0xFF22D3EE).withOpacity(0.4)
                      : Colors.white.withOpacity(0.06),
                  width: 1,
                ),
              ),
              child: Text(
                text,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ),
          ),
          if (isUser) const SizedBox(width: 4),
        ],
      ),
    );
  }
}
