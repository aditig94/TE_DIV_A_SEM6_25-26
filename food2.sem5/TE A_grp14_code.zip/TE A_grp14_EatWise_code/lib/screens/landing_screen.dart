import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fadeIn;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _featuresKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _fadeIn = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _scrollToFeatures() async {
    final context = _featuresKey.currentContext;
    if (context == null) return;
    await Scrollable.ensureVisible(
      context,
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeInOutCubic,
    );
  }

  void _navigateToAuth() {
    Navigator.of(context).pushNamed('/auth');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Container(
          color: const Color(0xFF0F172A),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: _buildTopBar(),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: FadeTransition(
                  opacity: _fadeIn,
                  child: SingleChildScrollView(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeroSection(),
                        const SizedBox(height: 60),
                        _buildFeaturesSection(),
                        const SizedBox(height: 60),
                        _buildHowItWorksSection(),
                        const SizedBox(height: 60),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [Color(0xFF22D3EE), Color(0xFFA855F7)],
                ),
              ),
              child: const Icon(Icons.eco, size: 18, color: Colors.black),
            ),
            const SizedBox(width: 10),
            Text(
              'EatWise',
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const Spacer(),
        TextButton(
          onPressed: _navigateToAuth,
          child: Text(
            'Login / Register',
            style: GoogleFonts.poppins(
              color: Colors.white70,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeroSection() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 800;
        return Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: isWide ? 3 : 4,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) {
                          return const LinearGradient(
                            colors: [
                              Color(0xFF22D3EE),
                              Color(0xFFA855F7),
                            ],
                          ).createShader(bounds);
                        },
                        blendMode: BlendMode.srcIn,
                        child: Text(
                          'Never Waste Food Again',
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'EatWise uses AI-powered expiry tracking and smart recipe suggestions '
                        'to help you use every ingredient before it goes bad.',
                        style: GoogleFonts.poppins(
                          color: Colors.white70,
                          fontSize: 15,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Wrap(
                        spacing: 16,
                        runSpacing: 12,
                        children: [
                          _PrimaryCtaButton(
                            label: 'Get Started',
                            onTap: _navigateToAuth,
                            large: true,
                          ),
                          _GhostCtaButton(
                            label: 'Learn More',
                            onTap: _scrollToFeatures,
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: Colors.greenAccent.shade400,
                            size: 18,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Track expiry • Reduce waste • Save money',
                            style: GoogleFonts.poppins(
                              color: Colors.white60,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (isWide) const SizedBox(width: 40),
                if (isWide)
                  Expanded(
                    flex: 3,
                    child: _HeroPreviewCard(),
                  ),
              ],
            ),
            if (!isWide) ...[
              const SizedBox(height: 32),
              _HeroPreviewCard(),
            ],
          ],
        );
      },
    );
  }

  Widget _buildFeaturesSection() {
    final features = [
      _Feature(
        icon: Icons.qr_code_scanner_rounded,
        title: 'Smart Scanning',
        description:
            'Scan barcodes and auto-detect expiry dates from global product datasets.',
      ),
      _Feature(
        icon: Icons.timeline_rounded,
        title: 'AI Expiry Radar',
        description:
            'See what needs attention today, this week, and what can wait.',
      ),
      _Feature(
        icon: Icons.auto_awesome_rounded,
        title: 'Recipe Suggestions',
        description:
            'Transform near-expiry items into chef-grade meals in a few taps.',
      ),
      _Feature(
        icon: Icons.notifications_active_rounded,
        title: 'Gentle Nudges',
        description:
            'Thoughtful reminders before food expires—never intrusive, always helpful.',
      ),
    ];

    return Column(
      key: _featuresKey,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Why teams choose EatWise',
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Built for busy households and teams that care about food, not spreadsheets.',
          style: GoogleFonts.poppins(
            color: Colors.white70,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 28),
        LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            final crossAxisCount = width > 900
                ? 4
                : width > 600
                    ? 2
                    : 1;
            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: features.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.2,
              ),
              itemBuilder: (context, index) {
                return _FeatureCard(feature: features[index]);
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildHowItWorksSection() {
    final steps = [
      _StepData(
        label: 'Scan',
        description:
            'Capture products with your camera or barcode scanner in seconds.',
      ),
      _StepData(
        label: 'Track',
        description:
            'See all your food in a single, prioritized expiry timeline.',
      ),
      _StepData(
        label: 'Cook Smart',
        description:
            'Get AI-powered recipe suggestions tailored to what needs using soon.',
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'How EatWise works',
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'From fridge to plate in three simple steps.',
          style: GoogleFonts.poppins(
            color: Colors.white70,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 28),
        LayoutBuilder(
          builder: (context, constraints) {
            final isVertical = constraints.maxWidth < 700;
            if (isVertical) {
              return Column(
                children: [
                  for (var i = 0; i < steps.length; i++) ...[
                    _HowStep(
                      index: i + 1,
                      data: steps[i],
                      vertical: true,
                      isLast: i == steps.length - 1,
                    ),
                    if (i != steps.length - 1) const SizedBox(height: 18),
                  ],
                ],
              );
            }
            return Row(
              children: [
                for (var i = 0; i < steps.length; i++) ...[
                  Expanded(
                    child: _HowStep(
                      index: i + 1,
                      data: steps[i],
                      vertical: false,
                      isLast: i == steps.length - 1,
                    ),
                  ),
                  if (i != steps.length - 1) const SizedBox(width: 18),
                ],
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.only(top: 32, bottom: 8),
      child: Column(
        children: [
          const Divider(color: Colors.white12, height: 1),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(
                '© ${DateTime.now().year} EatWise',
                style: GoogleFonts.poppins(
                  color: Colors.white54,
                  fontSize: 11,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () {},
                child: Text(
                  'Privacy',
                  style: GoogleFonts.poppins(
                    color: Colors.white60,
                    fontSize: 11,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {},
                child: Text(
                  'Terms',
                  style: GoogleFonts.poppins(
                    color: Colors.white60,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AnimatedBackground extends StatelessWidget {
  final AnimationController controller;

  const _AnimatedBackground({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final t = controller.value;
        final base = const Color(0xFF0F172A);
        final cyan = const Color(0xFF22D3EE);
        final purple = const Color(0xFFA855F7);

        final highlight = Color.lerp(
          cyan,
          purple,
          0.5 + 0.5 * (0.5 - (t - 0.5).abs()),
        )!;

        return Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(-0.6 + 0.2 * t, -1.0 + 0.4 * t),
              radius: 1.4,
              colors: [
                highlight.withOpacity(0.22),
                base,
              ],
            ),
          ),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(color: Colors.black.withOpacity(0.1)),
          ),
        );
      },
    );
  }
}

class _PrimaryCtaButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool large;

  const _PrimaryCtaButton({
    required this.label,
    required this.onTap,
    this.large = false,
  });

  @override
  State<_PrimaryCtaButton> createState() => _PrimaryCtaButtonState();
}

class _PrimaryCtaButtonState extends State<_PrimaryCtaButton> {
  bool _hovering = false;
  bool _pressed = false;

  void _setHover(bool value) {
    setState(() => _hovering = value);
  }

  void _setPressed(bool value) {
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final targetScale = _pressed
        ? 0.96
        : _hovering
            ? 1.03
            : 1.0;

    return MouseRegion(
      onEnter: (_) => _setHover(true),
      onExit: (_) => _setHover(false),
      child: GestureDetector(
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) {
          _setPressed(false);
          widget.onTap();
        },
        onTapCancel: () => _setPressed(false),
        child: TweenAnimationBuilder<double>(
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOutCubic,
          tween: Tween<double>(begin: 1.0, end: targetScale),
          builder: (context, scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: widget.large ? 26 : 20,
              vertical: widget.large ? 14 : 10,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF22D3EE),
                  Color(0xFFA855F7),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF22D3EE)
                      .withOpacity(_hovering ? 0.6 : 0.35),
                  blurRadius: 24,
                  spreadRadius: -6,
                  offset: const Offset(0, 14),
                ),
              ],
            ),
            child: Text(
              widget.label,
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: widget.large ? 14 : 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GhostCtaButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;

  const _GhostCtaButton({
    required this.label,
    required this.onTap,
  });

  @override
  State<_GhostCtaButton> createState() => _GhostCtaButtonState();
}

class _GhostCtaButtonState extends State<_GhostCtaButton> {
  bool _hovering = false;

  void _setHover(bool value) {
    setState(() => _hovering = value);
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _setHover(true),
      onExit: (_) => _setHover(false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            color: Colors.white.withOpacity(_hovering ? 0.06 : 0.03),
            border: Border.all(
              color: Colors.white.withOpacity(_hovering ? 0.45 : 0.2),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.label,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: 6),
              Icon(
                Icons.arrow_forward_rounded,
                color: Colors.white,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroPreviewCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF1E293B),
                Color(0xFF020617),
              ],
            ),
            border: Border.all(
              color: const Color(0xFF22D3EE).withOpacity(0.4),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF22D3EE).withOpacity(0.5),
                blurRadius: 32,
                spreadRadius: -10,
                offset: const Offset(0, 28),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Live expiry overview',
                style: GoogleFonts.spaceGrotesk(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'See what\'s expiring this week at a glance.',
                style: GoogleFonts.poppins(
                  color: Colors.white60,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  _MiniStat(
                    label: 'Items tracked',
                    value: '128',
                    color: const Color(0xFF22D3EE),
                  ),
                  const SizedBox(width: 12),
                  _MiniStat(
                    label: 'Saved this month',
                    value: '14 kg',
                    color: const Color(0xFFA855F7),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const _ExpiryBarPreview(),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _MiniStat({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Colors.white.withOpacity(0.02),
          border: Border.all(color: color.withOpacity(0.55), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 11,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ExpiryBarPreview extends StatelessWidget {
  const _ExpiryBarPreview();

  @override
  Widget build(BuildContext context) {
    final segments = [
      _ExpirySegment(
        label: 'Today',
        value: 3,
        color: const Color(0xFFFB7185),
      ),
      _ExpirySegment(
        label: '3 days',
        value: 7,
        color: const Color(0xFFF97316),
      ),
      _ExpirySegment(
        label: '7 days',
        value: 12,
        color: const Color(0xFF22C55E),
      ),
    ];

    final total = segments.fold<int>(0, (sum, s) => sum + s.value);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Expiry timeline',
          style: GoogleFonts.poppins(
            color: Colors.white70,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: Row(
            children: [
              for (final segment in segments)
                Expanded(
                  flex: segment.value,
                  child: Container(
                    height: 10,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          segment.color.withOpacity(0.8),
                          segment.color,
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: segments
              .map(
                (s) => Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: s.color,
                        borderRadius: BorderRadius.circular(999),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      s.label,
                      style: GoogleFonts.poppins(
                        color: Colors.white60,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 6),
        Text(
          '$total items tracked in the next 7 days',
          style: GoogleFonts.poppins(
            color: Colors.white54,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}

class _ExpirySegment {
  final String label;
  final int value;
  final Color color;

  _ExpirySegment({
    required this.label,
    required this.value,
    required this.color,
  });
}

class _Feature {
  final IconData icon;
  final String title;
  final String description;

  _Feature({
    required this.icon,
    required this.title,
    required this.description,
  });
}

class _FeatureCard extends StatefulWidget {
  final _Feature feature;

  const _FeatureCard({required this.feature});

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard> {
  bool _hovering = false;

  void _setHover(bool value) {
    setState(() => _hovering = value);
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _setHover(true),
      onExit: (_) => _setHover(false),
      child: TweenAnimationBuilder<double>(
        duration: const Duration(milliseconds: 180),
        tween: Tween<double>(
          begin: 1.0,
          end: _hovering ? 1.02 : 1.0,
        ),
        curve: Curves.easeOutCubic,
        builder: (context, scale, child) {
          return Transform.scale(scale: scale, child: child);
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                color: Colors.white.withOpacity(0.02),
                border: Border.all(
                  color: Colors.white.withOpacity(_hovering ? 0.35 : 0.15),
                ),
                boxShadow: [
                  if (_hovering)
                    BoxShadow(
                      color: const Color(0xFF22D3EE).withOpacity(0.35),
                      blurRadius: 24,
                      spreadRadius: -6,
                      offset: const Offset(0, 16),
                    ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.05),
                    ),
                    child: Icon(
                      widget.feature.icon,
                      size: 18,
                      color: const Color(0xFF22D3EE),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    widget.feature.title,
                    style: GoogleFonts.spaceGrotesk(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.feature.description,
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _StepData {
  final String label;
  final String description;

  _StepData({
    required this.label,
    required this.description,
  });
}

class _HowStep extends StatelessWidget {
  final int index;
  final _StepData data;
  final bool vertical;
  final bool isLast;

  const _HowStep({
    required this.index,
    required this.data,
    required this.vertical,
    required this.isLast,
  });

  @override
  Widget build(BuildContext context) {
    final circle = Container(
      width: 30,
      height: 30,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [Color(0xFF22D3EE), Color(0xFFA855F7)],
        ),
      ),
      child: Center(
        child: Text(
          index.toString(),
          style: GoogleFonts.spaceGrotesk(
            color: Colors.black,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );

    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          data.label,
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          data.description,
          style: GoogleFonts.poppins(
            color: Colors.white70,
            fontSize: 12,
            height: 1.5,
          ),
        ),
      ],
    );

    if (vertical) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              circle,
              if (!isLast)
                Container(
                  width: 2,
                  height: 40,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xFF22D3EE), Colors.transparent],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 14),
          Expanded(child: content),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            circle,
            if (!isLast)
              Expanded(
                child: Container(
                  height: 2,
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF22D3EE), Colors.transparent],
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 10),
        content,
      ],
    );
  }
}

