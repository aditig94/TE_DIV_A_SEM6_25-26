import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/profile_service.dart';
import '../services/products_service.dart';
import '../ui/app_shell.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _profile;
  List<Map<String, dynamic>> _recentProducts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        ProfileService.getProfile(),
        ProductsService.getProducts(),
      ]);
      final profile = results[0] as Map<String, dynamic>?;
      final products = results[1] as List<Map<String, dynamic>>;
      if (mounted) {
        setState(() {
          _profile = profile;
          _recentProducts = products.take(5).toList();
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    final email = user?.email ?? '—';
    final fullName = _profile?['full_name']?.toString() ??
        user?.userMetadata?['full_name']?.toString() ??
        'No name set';
    final goal = _profile?['goal']?.toString() ??
        user?.userMetadata?['goal']?.toString() ??
        'Not set';
    final allergies = _profile?['allergies']?.toString() ??
        user?.userMetadata?['allergies']?.toString() ??
        'None';
    final calorieTarget = _profile?['calorie_target'] ?? 2000;
    final calorieStr = '$calorieTarget kcal/day';

    if (_loading) {
      return const AppShell(
        child: Center(
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF22D3EE)),
          ),
        ),
      );
    }

    if (_error != null) {
      return AppShell(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: Color(0xFFF97316), size: 48),
              const SizedBox(height: 16),
              Text(
                'Could not load profile',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: _load,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return AppShell(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Profile',
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your account and preferences.',
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 28),
            _glassCard(
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 32,
                    backgroundColor: const Color(0xFF22D3EE).withOpacity(0.2),
                    child: Text(
                      fullName.isNotEmpty ? fullName[0].toUpperCase() : '?',
                      style: GoogleFonts.poppins(
                        color: const Color(0xFF22D3EE),
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          fullName,
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          email,
                          style: GoogleFonts.poppins(
                            color: Colors.white70,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _glassCard(
              onTap: () {},
              child: _row(
                icon: Icons.favorite_border,
                title: 'Diet / Goal',
                value: goal,
              ),
            ),
            const SizedBox(height: 12),
            _glassCard(
              onTap: () {},
              child: _row(
                icon: Icons.restaurant,
                title: 'Allergies',
                value: allergies,
              ),
            ),
            const SizedBox(height: 12),
            _glassCard(
              onTap: () {},
              child: _row(
                icon: Icons.local_fire_department_outlined,
                title: 'Calorie target',
                value: calorieStr,
              ),
            ),
            const SizedBox(height: 12),
            _glassCard(
              onTap: () {},
              child: _row(
                icon: Icons.history,
                title: 'Recent items',
                value: _recentProducts.isEmpty
                    ? 'No items yet'
                    : _recentProducts
                        .take(3)
                        .map((p) => (p['product_name'] ?? 'Unknown').toString())
                        .join(', ') +
                        (_recentProducts.length > 3 ? '...' : ''),
              ),
            ),
            const SizedBox(height: 12),
            _glassCard(
              onTap: () {
                Navigator.pushNamed(context, '/settings');
              },
              child: _row(
                icon: Icons.settings,
                title: 'Update Preferences',
                value: 'Edit profile, goal, allergies & more',
                trailing: const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.white54,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glassCard({
    required Widget child,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.white.withOpacity(0.04),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  Widget _row({
    required IconData icon,
    required String title,
    required String value,
    Widget? trailing,
  }) {
    return Row(
      children: [
        Icon(icon, size: 22, color: const Color(0xFF22D3EE).withOpacity(0.9)),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    );
  }
}
