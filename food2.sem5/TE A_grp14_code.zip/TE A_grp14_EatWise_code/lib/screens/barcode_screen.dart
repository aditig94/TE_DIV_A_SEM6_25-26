import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_scanner/mobile_scanner.dart';

import '../services/products_service.dart';
import '../ui/app_shell.dart';

class BarcodeScreen extends StatefulWidget {
  const BarcodeScreen({super.key});

  @override
  State<BarcodeScreen> createState() => _BarcodeScreenState();
}

class _BarcodeScreenState extends State<BarcodeScreen> {
  final TextEditingController _barcodeController = TextEditingController();

  bool isLoading = false;
  Map<String, dynamic>? productData;
  String? errorMessage;
  DateTime? expiryDate;

  @override
  void initState() {
    super.initState();
  }

  // 🔍 Fetch product from OpenFoodFacts
  Future<void> fetchProduct(String barcode) async {
    setState(() {
      isLoading = true;
      productData = null;
      errorMessage = null;
    });

    final url = 'https://world.openfoodfacts.org/api/v0/product/$barcode.json';

    try {
      final response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);

      if (data['status'] == 1) {
        // Parse expiry date
        DateTime? parsedExpiryDate;
        if (data['product']['expiration_date'] != null) {
          try {
            parsedExpiryDate = DateTime.parse(data['product']['expiration_date']);
          } catch (e) {
            parsedExpiryDate = null;
          }
        }

        setState(() {
          productData = data['product'];
          expiryDate = parsedExpiryDate;
        });

        // Save to Supabase (with or without expiry from API)
        try {
          await ProductsService.addProduct(
            productName: productData!['product_name'] ?? 'Unknown',
            barcode: barcode,
            expiryDate: parsedExpiryDate,
          );
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text(
                  'Saved to your list. Check "Expiry Alerts" on the home screen.',
                ),
              ),
            );
          }
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Could not save: $e')),
            );
          }
        }
      } else {
        setState(() {
          errorMessage = '❌ Product not found';
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = '⚠️ Error fetching product';
      });
    }

    setState(() {
      isLoading = false;
    });
  }

  // 📦 UI Card
  Widget productCard() {
    if (productData == null) return const SizedBox();

    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              productData!['product_name'] ?? 'Unknown product',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text('Brand: ${productData!['brands'] ?? 'N/A'}'),
            Text('Category: ${productData!['categories'] ?? 'N/A'}'),
            Text('Quantity: ${productData!['quantity'] ?? 'N/A'}'),
            const SizedBox(height: 12),
            if (expiryDate != null) ...[
              Text(
                "Expiry: ${expiryDate!.day}/${expiryDate!.month}/${expiryDate!.year}",
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                "Days left: ${expiryDate!.difference(DateTime.now()).inDays}",
                style: const TextStyle(color: Colors.red),
              ),
            ] else
              const Text(
                "No expiry info available",
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Scan or enter barcode',
                  style: GoogleFonts.spaceGrotesk(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Camera scanning works best on mobile. On web, use manual entry when needed.',
                  style: GoogleFonts.poppins(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 5,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF020617).withOpacity(0.95),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Live scanner',
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 260,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: Container(
                                  color: const Color(0xFF020617),
                                  child: MobileScanner(
                                    onDetect: (capture) {
                                      final List<Barcode> barcodes =
                                          capture.barcodes;
                                      if (barcodes.isNotEmpty) {
                                        final String? code =
                                            barcodes.first.rawValue;
                                        if (code != null) {
                                          fetchProduct(code);
                                        }
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Tip: On web, browsers may restrict camera access. Use your phone for the smoothest experience.',
                              style: GoogleFonts.poppins(
                                color: Colors.white54,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      flex: 4,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF020617).withOpacity(0.95),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Manual entry',
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: _barcodeController,
                              keyboardType: TextInputType.number,
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                              decoration: InputDecoration(
                                labelText: 'Enter barcode manually',
                                labelStyle: GoogleFonts.poppins(
                                  color: Colors.white70,
                                  fontSize: 13,
                                ),
                                filled: true,
                                fillColor: const Color(0xFF020617),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF1F2937),
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF1F2937),
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF22D3EE),
                                  ),
                                ),
                                suffixIcon: IconButton(
                                  icon: const Icon(Icons.search,
                                      color: Colors.white70),
                                  onPressed: () {
                                    final code =
                                        _barcodeController.text.trim();
                                    if (code.isNotEmpty) {
                                      fetchProduct(code);
                                    }
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            if (isLoading)
                              const Center(
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor:
                                      AlwaysStoppedAnimation<Color>(
                                    Color(0xFF22D3EE),
                                  ),
                                ),
                              ),
                            if (errorMessage != null)
                              Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: Text(
                                  errorMessage!,
                                  style: GoogleFonts.poppins(
                                    color: Colors.redAccent,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                if (productData != null) productCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
