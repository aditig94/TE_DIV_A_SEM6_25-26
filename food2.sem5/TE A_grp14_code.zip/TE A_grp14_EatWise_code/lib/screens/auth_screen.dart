import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/profile_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _allergiesController = TextEditingController();
  bool _isLogin = true;
  bool _loading = false;
  String _selectedGoal = 'Any';

  final supabase = Supabase.instance.client;

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _allergiesController.dispose();
    super.dispose();
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  String _userFriendlyAuthError(dynamic e) {
    final s = e.toString().toLowerCase();
    if (s.contains('invalid login')) {
      return 'Invalid email or password. Please try again.';
    }
    if (s.contains('email not confirmed')) {
      return 'Please confirm your email before signing in.';
    }
    if (s.contains('user already registered')) {
      return 'An account with this email already exists. Try logging in.';
    }
    if (s.contains('password')) {
      return 'Password should be at least 6 characters.';
    }
    return 'Something went wrong. Please try again.';
  }

  Future<void> _authenticate() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty) {
      _showSnackBar('Please enter your email.');
      return;
    }
    if (password.isEmpty) {
      _showSnackBar('Please enter your password.');
      return;
    }
    if (!_isLogin) {
      final fullName = _fullNameController.text.trim();
      if (fullName.isEmpty) {
        _showSnackBar('Please enter your full name.');
        return;
      }
    }

    setState(() => _loading = true);

    try {
      if (_isLogin) {
        final res = await supabase.auth.signInWithPassword(
          email: email,
          password: password,
        );

        if (res.user != null) {
          if (mounted) Navigator.pushReplacementNamed(context, '/home');
        } else {
          _showSnackBar('Login failed. Check your credentials.');
        }
      } else {
        final fullName = _fullNameController.text.trim();
        final allergies = _allergiesController.text.trim();
        final data = {
          'full_name': fullName,
          'goal': _selectedGoal,
          'allergies': allergies.isEmpty ? null : allergies,
        };

        final res = await supabase.auth.signUp(
          email: email,
          password: password,
          data: data,
        );

        if (res.user != null) {
          try {
            await ProfileService.insertProfile(
              id: res.user!.id,
              fullName: fullName,
              goal: _selectedGoal,
              allergies: allergies.isEmpty ? null : allergies,
              calorieTarget: 2000,
            );
          } catch (_) {
            // Profile insert may fail if table not set up; auth still succeeded
          }
          _showSnackBar('Sign up successful. Please verify your email.');
          setState(() => _isLogin = true);
        } else {
          _showSnackBar('Sign up failed. Try again.');
        }
      }
    } catch (e) {
      _showSnackBar(_userFriendlyAuthError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final titleText = 'EatWise';
    final subtitleText = _isLogin ? 'Welcome back' : 'Create your account';

    InputDecoration _inputDecoration(String label, {String? hint}) {
      return InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: GoogleFonts.poppins(
          color: Colors.white70,
          fontSize: 13,
        ),
        hintStyle: GoogleFonts.poppins(
          color: Colors.white38,
          fontSize: 12,
        ),
        filled: true,
        fillColor: const Color(0xFF020617).withOpacity(0.85),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF1F2937), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF22D3EE), width: 1.4),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.redAccent, width: 1.2),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.redAccent, width: 1.2),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF020617),
              Color(0xFF0F172A),
              Color(0xFF111827),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Align(
              alignment: Alignment.center,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                    child: Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white.withOpacity(0.03),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.06),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.6),
                            blurRadius: 40,
                            spreadRadius: -12,
                            offset: const Offset(0, 26),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 30,
                                height: 30,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    colors: [
                                      Color(0xFF22D3EE),
                                      Color(0xFFA855F7),
                                    ],
                                  ),
                                ),
                                child: const Icon(
                                  Icons.eco,
                                  size: 18,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                titleText,
                                style: GoogleFonts.spaceGrotesk(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          Text(
                            subtitleText,
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _isLogin
                                ? 'Log in to manage your expiry radar.'
                                : 'Sign up to start tracking your food intelligently.',
                            style: GoogleFonts.poppins(
                              color: Colors.white70,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 28),
                          if (!_isLogin) ...[
                            TextField(
                              controller: _fullNameController,
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                              textCapitalization: TextCapitalization.words,
                              decoration: _inputDecoration('Full Name'),
                            ),
                            const SizedBox(height: 20),
                          ],
                          TextField(
                            controller: _emailController,
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 13,
                            ),
                            keyboardType: TextInputType.emailAddress,
                            decoration: _inputDecoration('Email'),
                          ),
                          const SizedBox(height: 20),
                          TextField(
                            controller: _passwordController,
                            obscureText: true,
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 13,
                            ),
                            decoration: _inputDecoration('Password'),
                          ),
                          if (!_isLogin) ...[
                            const SizedBox(height: 20),
                            TextField(
                              controller: _allergiesController,
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                              maxLines: 2,
                              decoration: _inputDecoration(
                                'Allergies (if any)',
                                hint: 'e.g. Nuts, Dairy',
                              ),
                            ),
                            const SizedBox(height: 20),
                            DropdownButtonFormField<String>(
                              value: _selectedGoal,
                              dropdownColor: const Color(0xFF020617),
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                              decoration: _inputDecoration('Your goal'),
                              items: const [
                                DropdownMenuItem(
                                  value: 'Lose weight',
                                  child: Text('Lose weight'),
                                ),
                                DropdownMenuItem(
                                  value: 'Gain weight',
                                  child: Text('Gain weight'),
                                ),
                                DropdownMenuItem(
                                  value: 'Any',
                                  child: Text('Any'),
                                ),
                              ],
                              onChanged: (v) =>
                                  setState(() => _selectedGoal = v ?? 'Any'),
                            ),
                          ],
                          const SizedBox(height: 24),
                          SizedBox(
                            width: double.infinity,
                            child: MouseRegion(
                              cursor: _loading
                                  ? SystemMouseCursors.basic
                                  : SystemMouseCursors.click,
                              child: ElevatedButton(
                                onPressed: _loading ? null : _authenticate,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF22D3EE),
                                  foregroundColor: Colors.black,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  elevation: 0,
                                ).copyWith(
                                  overlayColor:
                                      MaterialStateProperty.resolveWith(
                                    (states) {
                                      if (states
                                          .contains(MaterialState.hovered)) {
                                        return const Color(0xFF22D3EE)
                                            .withOpacity(0.15);
                                      }
                                      if (states
                                          .contains(MaterialState.pressed)) {
                                        return const Color(0xFF22D3EE)
                                            .withOpacity(0.25);
                                      }
                                      return null;
                                    },
                                  ),
                                ),
                                child: _loading
                                    ? const SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.4,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            Colors.black,
                                          ),
                                        ),
                                      )
                                    : Text(
                                        _isLogin ? 'Login' : 'Sign Up',
                                        style: GoogleFonts.poppins(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Center(
                            child: TextButton(
                              onPressed: _loading
                                  ? null
                                  : () {
                                      setState(
                                          () => _isLogin = !_isLogin);
                                    },
                              child: Text(
                                _isLogin
                                    ? 'Don\'t have an account? Create one'
                                    : 'Already have an account? Login',
                                style: GoogleFonts.poppins(
                                  color: Colors.white60,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}