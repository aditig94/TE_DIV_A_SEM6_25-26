import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../ui/app_shell.dart';

class MealDetails extends StatefulWidget {
  const MealDetails({super.key});

  @override
  State<MealDetails> createState() => _MealDetailsScreenState();
}

class _MealDetailsScreenState extends State<MealDetails> {
  final foodCtrl = TextEditingController();
  DateTime? purchaseDate;
  DateTime? cookedDate;

  String storage = 'Room';
  String status = '';

  void _pickDate(bool isPurchase) async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime.now(),
    );

    if (date != null) {
      setState(() {
        isPurchase ? purchaseDate = date : cookedDate = date;
      });
    }
  }

  void _calculateStatus() {
    if (foodCtrl.text.isEmpty || cookedDate == null) {
      setState(() {
        status = "Please fill all details";
      });
      return;
    }

    final daysOld = DateTime.now().difference(cookedDate!).inDays;

    int safeDays;
    switch (storage) {
      case 'Refrigerator':
        safeDays = 3;
        break;
      case 'Freezer':
        safeDays = 7;
        break;
      default:
        safeDays = 1;
    }

    if (daysOld <= safeDays) {
      status = "✅ Safe to eat ($daysOld days old)";
    } else if (daysOld == safeDays + 1) {
      status = "⚠ Consume today";
    } else {
      status = "❌ Expired";
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: const Color(0xFF020617).withOpacity(0.95),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Meal safety checker',
                    style: GoogleFonts.spaceGrotesk(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Estimate whether a cooked meal is still safe to eat based on dates and storage.',
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Food name',
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextField(
                    controller: foodCtrl,
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 13,
                    ),
                    decoration: InputDecoration(
                      hintText: 'e.g. Paneer Curry',
                      hintStyle: GoogleFonts.poppins(
                        color: Colors.white38,
                        fontSize: 12,
                      ),
                      filled: true,
                      fillColor: const Color(0xFF020617),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFF1F2937)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFF1F2937)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFF22D3EE)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: _dateTile(
                          'Purchase date',
                          purchaseDate,
                          () => _pickDate(true),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _dateTile(
                          'Cooked date',
                          cookedDate,
                          () => _pickDate(false),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Storage temperature',
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 10,
                    children: ['Room', 'Refrigerator', 'Freezer']
                        .map(
                          (e) => ChoiceChip(
                            label: Text(
                              e,
                              style: GoogleFonts.poppins(
                                fontSize: 12,
                                color: storage == e
                                    ? Colors.white
                                    : Colors.white70,
                              ),
                            ),
                            selected: storage == e,
                            selectedColor: const Color(0xFF22D3EE),
                            backgroundColor: const Color(0xFF020617),
                            onSelected: (_) {
                              setState(() {
                                storage = e;
                              });
                            },
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _calculateStatus,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF22D3EE),
                        foregroundColor: Colors.black,
                        padding:
                            const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: Text(
                        'Check food status',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (status.isNotEmpty)
                    Center(
                      child: Text(
                        status,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _dateTile(String title, DateTime? date, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF1F2937)),
          color: const Color(0xFF020617),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_today,
                size: 18, color: Colors.white70),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    date == null
                        ? 'Select date'
                        : date.toLocal().toString().split(' ')[0],
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}