import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/products_service.dart';
import '../ui/app_shell.dart';
import 'add_product_screen.dart';
import 'barcode_screen.dart';
import 'expiry_alerts_screen.dart';
import 'meal_details.dart';
import 'recipe_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  bool _checkedAlerts = false;

  late final AnimationController _controller;
  late final Animation<double> _fadeAnimation;

  List<Map<String, dynamic>> _products = [];
  int _totalProducts = 0;
  int _expiringSoon = 0;
  int _expired = 0;
  bool _loadingStats = true;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );

    _controller.forward();

    // Run after first frame so context is safe for dialogs/snackbars
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showPriorityExpiryNotificationIfNeeded();
      _loadDashboardStats();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadDashboardStats() async {
    final decoded = await ProductsService.getProducts();
    final now = DateTime.now();

    int total = decoded.length;
    int expiringSoon = 0;
    int expired = 0;

    for (final item in decoded) {
      final expiryStr = item['expiryDate'] as String?;
      if (expiryStr == null) continue;
      try {
        final expiry = DateTime.parse(expiryStr);
        final daysLeft = expiry.difference(now).inDays;
        if (daysLeft < 0) {
          expired++;
        } else if (daysLeft <= 3) {
          expiringSoon++;
        }
      } catch (_) {
        // ignore parse errors for stats
      }
    }

    if (!mounted) return;

    setState(() {
      _products = decoded;
      _totalProducts = total;
      _expiringSoon = expiringSoon;
      _expired = expired;
      _loadingStats = false;
    });
  }

  Future<void> _showPriorityExpiryNotificationIfNeeded() async {
    if (_checkedAlerts) return;
    _checkedAlerts = true;

    final decoded = await ProductsService.getProducts();
    if (decoded.isEmpty) return;

    final now = DateTime.now();
    final List<Map<String, dynamic>> items = [];

    for (final mapItem in decoded) {
      final expiryStr = mapItem['expiryDate'] as String?;
      if (expiryStr == null) continue;

      DateTime? expiry;
      try {
        expiry = DateTime.parse(expiryStr);
      } catch (_) {
        continue;
      }

      final daysLeft = expiry.difference(now).inDays;

      // Priority: already expired or within next 3 days
      if (daysLeft <= 3) {
        items.add({
          ...mapItem,
          'expiryDateTime': expiry,
          'daysLeft': daysLeft,
        });
      }
    }

    if (items.isEmpty || !mounted) return;

    // Sort by soonest expiry / most overdue
    items.sort((a, b) {
      final aDays = a['daysLeft'] as int? ?? 9999;
      final bDays = b['daysLeft'] as int? ?? 9999;
      return aDays.compareTo(bDays);
    });

    final topItems = items.take(3).toList();

    String buildLine(Map<String, dynamic> p) {
      final name = (p['product_name'] ?? 'Unknown').toString();
      final days = p['daysLeft'] as int? ?? 0;
      if (days < 0) {
        return '• $name – already expired';
      } else if (days == 0) {
        return '• $name – expires today';
      } else {
        return '• $name – in $days days';
      }
    }

    final message = StringBuffer();
    message.writeln(
      'Some products will expire soon. Please consume them at the earliest.',
    );
    message.writeln('');
    for (final p in topItems) {
      message.writeln(buildLine(p));
    }
    if (items.length > topItems.length) {
      message.writeln('…and ${items.length - topItems.length} more.');
    }
    message.writeln('');
    message.writeln('Open "Expiry Alerts" to see the full priority list.');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF0F172A),
        title: Text(
          'Expiry reminder',
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          message.toString(),
          style: GoogleFonts.poppins(
            color: Colors.white70,
            fontSize: 13,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: GoogleFonts.poppins(
                color: const Color(0xFF22D3EE),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ExpiryAlertsScreen(),
                ),
              );
            },
            child: Text(
              'View All',
              style: GoogleFonts.poppins(
                color: const Color(0xFF22D3EE),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_expiringSoon > 0 || _expired > 0) _buildAlertBanner(),
              if (_expiringSoon > 0 || _expired > 0)
                const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Flexible(
                    flex: 7,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildGreeting(),
                        const SizedBox(height: 20),
                        _buildStatsRow(),
                        const SizedBox(height: 20),
                        _buildPrimaryScanCard(context),
                        const SizedBox(height: 20),
                        _buildProductTable(),
                      ],
                    ),
                  ),
                  const SizedBox(width: 24),
                  Flexible(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildExpiringSoonPanel(),
                        const SizedBox(height: 20),
                        _buildQuickActions(context),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAlertBanner() {
    final totalUrgent = _expiringSoon + _expired;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color(0xFF7F1D1D).withOpacity(0.85),
        border: Border.all(color: const Color(0xFFF97373).withOpacity(0.7)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded,
              color: Color(0xFFFECACA), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$totalUrgent items are expired or expiring within 3 days. Review your expiry alerts.',
              style: GoogleFonts.poppins(
                color: const Color(0xFFFECACA),
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGreeting() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome back',
                style: GoogleFonts.spaceGrotesk(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Your AI-powered food dashboard is ready.',
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            color: const Color(0xFF1E293B),
            border: Border.all(
              color: const Color(0xFF22D3EE).withOpacity(0.6),
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF22D3EE).withOpacity(0.45),
                blurRadius: 16,
                spreadRadius: -4,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.shield_moon_outlined,
                size: 18,
                color: Color(0xFF22D3EE),
              ),
              const SizedBox(width: 6),
              Text(
                'Freshness Guard · Live',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatsRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isNarrow = constraints.maxWidth < 600;
        final children = [
          _StatCard(
            label: 'Total products',
            value: _loadingStats ? '—' : _totalProducts.toString(),
            accentColor: const Color(0xFF22D3EE),
          ),
          _StatCard(
            label: 'Expiring soon',
            value: _loadingStats ? '—' : _expiringSoon.toString(),
            accentColor: const Color(0xFFF97316),
          ),
          _StatCard(
            label: 'Expired',
            value: _loadingStats ? '—' : _expired.toString(),
            accentColor: const Color(0xFFFB7185),
          ),
        ];

        if (isNarrow) {
          return Column(
            children: [
              Row(
                children: [
                  Expanded(child: children[0]),
                  const SizedBox(width: 12),
                  Expanded(child: children[1]),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: children[2]),
                ],
              ),
            ],
          );
        }

        return Row(
          children: [
            Expanded(child: children[0]),
            const SizedBox(width: 16),
            Expanded(child: children[1]),
            const SizedBox(width: 16),
            Expanded(child: children[2]),
          ],
        );
      },
    );
  }

  Widget _buildPrimaryScanCard(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const BarcodeScreen(),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF22D3EE),
              Color(0xFF0EA5E9),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF22D3EE).withOpacity(0.4),
              blurRadius: 26,
              spreadRadius: -8,
              offset: const Offset(0, 18),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withOpacity(0.1),
              ),
              child: const Icon(
                Icons.qr_code_scanner_rounded,
                color: Colors.black,
                size: 26,
              ),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Scan Food',
                    style: GoogleFonts.spaceGrotesk(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Capture new items via barcode in a single click.',
                    style: GoogleFonts.poppins(
                      color: Colors.black.withOpacity(0.8),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.north_east, color: Colors.black, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildProductTable() {
    if (_products.isEmpty && !_loadingStats) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: const Color(0xFF020617).withOpacity(0.9),
          border: Border.all(color: Colors.white12),
        ),
        child: Text(
          'No products yet. Start by scanning or adding a product.',
          style: GoogleFonts.poppins(
            color: Colors.white60,
            fontSize: 13,
          ),
        ),
      );
    }

    final now = DateTime.now();
    final List<_ParsedProduct> parsed = _products.map((item) {
      DateTime? expiry;
      final expiryStr = item['expiryDate'] as String?;
      if (expiryStr != null) {
        try {
          expiry = DateTime.parse(expiryStr);
        } catch (_) {
          expiry = null;
        }
      }
      int? daysLeft;
      if (expiry != null) {
        daysLeft = expiry.difference(now).inDays;
      }
      return _ParsedProduct(
        name: (item['product_name'] ?? 'Unknown').toString(),
        barcode: (item['barcode'] ?? '').toString(),
        expiry: expiry,
        daysLeft: daysLeft,
      );
    }).toList();

    parsed.sort((a, b) {
      final aDays = a.daysLeft ?? 9999;
      final bDays = b.daysLeft ?? 9999;
      return aDays.compareTo(bDays);
    });

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: const Color(0xFF020617).withOpacity(0.9),
        border: Border.all(color: Colors.white12, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Text(
                  'Product overview',
                  style: GoogleFonts.spaceGrotesk(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                Text(
                  '${parsed.length} items',
                  style: GoogleFonts.poppins(
                    color: Colors.white54,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          const Divider(color: Colors.white12, height: 1),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                _tableHeaderCell('Name', flex: 4),
                _tableHeaderCell('Expiry', flex: 3),
                _tableHeaderCell('Days left', flex: 2, alignEnd: true),
                _tableHeaderCell('Status', flex: 2, alignEnd: true),
              ],
            ),
          ),
          const Divider(color: Colors.white12, height: 1),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: parsed.length,
            itemBuilder: (context, index) {
              final p = parsed[index];
              final status = _statusFor(p);
              final bg = index.isEven
                  ? Colors.white.withOpacity(0.01)
                  : Colors.white.withOpacity(0.03);
              return Container(
                color: bg,
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
                child: Row(
                  children: [
                    Expanded(
                      flex: 4,
                      child: Text(
                        p.name,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        p.expiry != null
                            ? '${p.expiry!.day}/${p.expiry!.month}/${p.expiry!.year}'
                            : '—',
                        style: GoogleFonts.poppins(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          p.daysLeft != null ? '${p.daysLeft}' : '—',
                          style: GoogleFonts.poppins(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(999),
                            color: status.color.withOpacity(0.18),
                          ),
                          child: Text(
                            status.label,
                            style: GoogleFonts.poppins(
                              color: status.color,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _tableHeaderCell(String text,
      {required int flex, bool alignEnd = false}) {
    return Expanded(
      flex: flex,
      child: Align(
        alignment:
            alignEnd ? Alignment.centerRight : Alignment.centerLeft,
        child: Text(
          text,
          style: GoogleFonts.poppins(
            color: Colors.white54,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  _Status _statusFor(_ParsedProduct p) {
    if (p.daysLeft == null) {
      return const _Status('Unknown', Colors.grey);
    }
    if (p.daysLeft! < 0) {
      return const _Status('Expired', Color(0xFFFB7185));
    }
    if (p.daysLeft == 0 || p.daysLeft! <= 3) {
      return const _Status('Soon', Color(0xFFF97316));
    }
    return const _Status('Fresh', Color(0xFF22C55E));
  }

  Widget _buildExpiringSoonPanel() {
    final now = DateTime.now();
    final List<_ParsedProduct> parsed = _products.map((item) {
      DateTime? expiry;
      final expiryStr = item['expiryDate'] as String?;
      if (expiryStr != null) {
        try {
          expiry = DateTime.parse(expiryStr);
        } catch (_) {
          expiry = null;
        }
      }
      int? daysLeft;
      if (expiry != null) {
        daysLeft = expiry.difference(now).inDays;
      }
      return _ParsedProduct(
        name: (item['product_name'] ?? 'Unknown').toString(),
        barcode: (item['barcode'] ?? '').toString(),
        expiry: expiry,
        daysLeft: daysLeft,
      );
    }).where((p) => p.daysLeft != null && p.daysLeft! <= 3).toList();

    parsed.sort((a, b) {
      final aDays = a.daysLeft ?? 9999;
      final bDays = b.daysLeft ?? 9999;
      return aDays.compareTo(bDays);
    });

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: const Color(0xFF020617).withOpacity(0.9),
        border: Border.all(color: Colors.white12),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Expiring soon',
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          if (parsed.isEmpty)
            Text(
              'Nothing urgent. You\'re all clear.',
              style: GoogleFonts.poppins(
                color: Colors.white54,
                fontSize: 12,
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: parsed.length,
              itemBuilder: (context, index) {
                final p = parsed[index];
                final status = _statusFor(p);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          p.name,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        p.daysLeft != null
                            ? '${p.daysLeft}d'
                            : '—',
                        style: GoogleFonts.poppins(
                          color: Colors.white60,
                          fontSize: 11,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(999),
                          color: status.color.withOpacity(0.18),
                        ),
                        child: Text(
                          status.label,
                          style: GoogleFonts.poppins(
                            color: status.color,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: const Color(0xFF020617).withOpacity(0.9),
        border: Border.all(color: Colors.white12),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick actions',
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          _quickActionButton(
            context,
            icon: Icons.add_circle_outline_rounded,
            label: 'Add Product',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AddProductScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          _quickActionButton(
            context,
            icon: Icons.restaurant_menu_rounded,
            label: 'Add Meal',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MealDetails(),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          _quickActionButton(
            context,
            icon: Icons.auto_awesome_rounded,
            label: 'Smart Recipes',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const RecipeScreen(),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          _quickActionButton(
            context,
            icon: Icons.timer_rounded,
            label: 'Expiry Alerts',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ExpiryAlertsScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _quickActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return OutlinedButton.icon(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Colors.white24),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      icon: Icon(icon, size: 18),
      label: Text(
        label,
        style: GoogleFonts.poppins(
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color accentColor;

  const _StatCard({
    required this.label,
    required this.value,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          decoration: BoxDecoration(
            color: const Color(0xFF0B1220).withOpacity(0.85),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: accentColor.withOpacity(0.7),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: accentColor.withOpacity(0.42),
                blurRadius: 22,
                spreadRadius: -8,
                offset: const Offset(0, 16),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                value,
                style: GoogleFonts.spaceGrotesk(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ParsedProduct {
  final String name;
  final String barcode;
  final DateTime? expiry;
  final int? daysLeft;

  _ParsedProduct({
    required this.name,
    required this.barcode,
    required this.expiry,
    required this.daysLeft,
  });
}

class _Status {
  final String label;
  final Color color;

  const _Status(this.label, this.color);
}
