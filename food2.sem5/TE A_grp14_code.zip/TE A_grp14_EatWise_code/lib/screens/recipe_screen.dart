import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../ui/app_shell.dart';

class RecipeScreen extends StatefulWidget {
  const RecipeScreen({super.key});

  @override
  State<RecipeScreen> createState() => _RecipeScreenState();
}

class _RecipeScreenState extends State<RecipeScreen> {
  final TextEditingController ingredientCtrl = TextEditingController();

  String foodType = 'Veg';
  String storage = 'Fridge';
  int daysOld = 0;

  bool loading = false;
  List<Map<String, String>> recipes = [];

  /// 🔑 Replace with your YouTube API key
  final String youtubeApiKey = 'AIzaSyCixIVufOZYaTSqs5ch3VUllmPVYg6XEAs';

  Future<void> fetchRecipes() async {
    if (ingredientCtrl.text.isEmpty) return;

    setState(() {
      loading = true;
      recipes.clear();
    });

    final query =
        '${foodType == "Veg" ? "vegetarian" : "non veg"} ${ingredientCtrl.text} recipe';

    final url =
        'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=5&q=$query&key=$youtubeApiKey';

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      for (var item in data['items']) {
        recipes.add({
          'title': item['snippet']['title'],
          'videoId': item['id']['videoId'],
          'thumbnail': item['snippet']['thumbnails']['medium']['url'],
        });
      }
    }

    setState(() => loading = false);
  }

  void openVideo(String id) async {
    final uri = Uri.parse('https://www.youtube.com/watch?v=$id');
    if (await canLaunchUrl(uri)) {
      launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Smart Recipes',
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Turn near-expiry ingredients into useful meals.',
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 24),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 900),
                child: _inputCard(),
              ),
            ),
            const SizedBox(height: 32),
            if (loading)
              const Center(
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor:
                      AlwaysStoppedAnimation<Color>(Color(0xFF22D3EE)),
                ),
              )
            else
              _recipeList(),
          ],
        ),
      ),
    );
  }

  Widget _inputCard() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF020617).withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white12),
      ),
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: ingredientCtrl,
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 13,
            ),
            decoration: InputDecoration(
              labelText: 'Main ingredient',
              hintText: 'e.g. Tomatoes, Rice, Paneer',
              labelStyle: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 13,
              ),
              hintStyle: GoogleFonts.poppins(
                color: Colors.white38,
                fontSize: 12,
              ),
              filled: true,
              fillColor: const Color(0xFF020617),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFF1F2937)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFF1F2937)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFF22D3EE)),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField(
                  value: foodType,
                  dropdownColor: const Color(0xFF020617),
                  decoration: InputDecoration(
                    labelText: 'Food type',
                    labelStyle: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 13,
                    ),
                    filled: true,
                    fillColor: const Color(0xFF020617),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: Color(0xFF1F2937)),
                    ),
                  ),
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 13,
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Veg', child: Text('Veg')),
                    DropdownMenuItem(
                        value: 'Non-Veg', child: Text('Non-Veg')),
                  ],
                  onChanged: (val) => setState(() => foodType = val!),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: DropdownButtonFormField(
                  value: storage,
                  dropdownColor: const Color(0xFF020617),
                  decoration: InputDecoration(
                    labelText: 'Stored in',
                    labelStyle: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 13,
                    ),
                    filled: true,
                    fillColor: const Color(0xFF020617),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: Color(0xFF1F2937)),
                    ),
                  ),
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 13,
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Fridge', child: Text('Fridge')),
                    DropdownMenuItem(
                        value: 'Room', child: Text('Room Temp')),
                  ],
                  onChanged: (val) => setState(() => storage = val!),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Text(
                'Days old:',
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Slider(
                  value: daysOld.toDouble(),
                  min: 0,
                  max: 7,
                  divisions: 7,
                  label: '$daysOld days',
                  onChanged: (val) =>
                      setState(() => daysOld = val.toInt()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Center(
            child: SizedBox(
              width: 220,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.search),
                label: Text(
                  'Find Recipes',
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                onPressed: fetchRecipes,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF22D3EE),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _recipeList() {
    if (recipes.isEmpty) {
      return Center(
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF020617).withOpacity(0.95),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.restaurant_menu,
                  color: Colors.white60, size: 22),
              const SizedBox(width: 12),
              Text(
                'Enter ingredients to generate recipe suggestions.',
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final crossAxisCount = width > 900 ? 3 : 2;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: recipes.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: 0.95,
          ),
          itemBuilder: (_, i) {
            final recipe = recipes[i];
            return InkWell(
              onTap: () => openVideo(recipe['videoId']!),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF020617).withOpacity(0.95),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(18),
                      ),
                      child: Image.network(
                        recipe['thumbnail']!,
                        height: 120,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            recipe['title']!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'YouTube • Video',
                            style: GoogleFonts.poppins(
                              color: Colors.white60,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () =>
                                  openVideo(recipe['videoId']!),
                              icon: const Icon(Icons.play_circle_fill,
                                  size: 18, color: Colors.red),
                              label: Text(
                                'Watch',
                                style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}