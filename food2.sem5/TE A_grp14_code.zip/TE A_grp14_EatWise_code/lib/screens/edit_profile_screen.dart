import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/profile_service.dart';
import '../ui/app_shell.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _fullNameController = TextEditingController();
  final _allergiesController = TextEditingController();
  final _calorieController = TextEditingController();
  String _selectedGoal = 'Any';
  bool _loading = false;
  bool _saving = false;

  static const List<String> _goals = ['Lose weight', 'Gain weight', 'Any'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _allergiesController.dispose();
    _calorieController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final user = Supabase.instance.client.auth.currentUser;
    final profile = await ProfileService.getProfile();
    if (mounted) {
      _fullNameController.text = profile?['full_name']?.toString() ??
          user?.userMetadata?['full_name']?.toString() ??
          '';
      _allergiesController.text = profile?['allergies']?.toString() ??
          user?.userMetadata?['allergies']?.toString() ??
          '';
      final goal = profile?['goal']?.toString() ?? user?.userMetadata?['goal']?.toString();
      _selectedGoal = goal != null && _goals.contains(goal) ? goal : 'Any';
      final cal = profile?['calorie_target'];
      _calorieController.text = cal != null ? cal.toString() : '2000';
      setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final fullName = _fullNameController.text.trim();
    if (fullName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your full name.')),
      );
      return;
    }
    int? calorieTarget;
    if (_calorieController.text.trim().isNotEmpty) {
      calorieTarget = int.tryParse(_calorieController.text.trim());
      if (calorieTarget == null || calorieTarget < 500 || calorieTarget > 5000) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Enter a calorie target between 500 and 5000.')),
        );
        return;
      }
    }
    setState(() => _saving = true);
    try {
      await ProfileService.updateProfile(
        fullName: fullName,
        goal: _selectedGoal,
        allergies: _allergiesController.text.trim().isEmpty
            ? null
            : _allergiesController.text.trim(),
        calorieTarget: calorieTarget,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated.')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _decoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.poppins(color: Colors.white70, fontSize: 13),
      filled: true,
      fillColor: const Color(0xFF020617).withOpacity(0.85),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF1F2937)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF22D3EE)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const AppShell(
        child: Center(
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF22D3EE)),
          ),
        ),
      );
    }

    return AppShell(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Update preferences',
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Edit your name, goal, allergies and calorie target.',
              style: GoogleFonts.poppins(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 28),
            TextField(
              controller: _fullNameController,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
              textCapitalization: TextCapitalization.words,
              decoration: _decoration('Full name'),
            ),
            const SizedBox(height: 20),
            DropdownButtonFormField<String>(
              value: _selectedGoal,
              dropdownColor: const Color(0xFF020617),
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
              decoration: _decoration('Goal'),
              items: _goals
                  .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                  .toList(),
              onChanged: (v) => setState(() => _selectedGoal = v ?? 'Any'),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _allergiesController,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
              maxLines: 2,
              decoration: _decoration('Allergies (e.g. Nuts, Dairy)'),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _calorieController,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
              keyboardType: TextInputType.number,
              decoration: _decoration('Calorie target (kcal/day)'),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF22D3EE),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
                        ),
                      )
                    : Text(
                        'Save changes',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
