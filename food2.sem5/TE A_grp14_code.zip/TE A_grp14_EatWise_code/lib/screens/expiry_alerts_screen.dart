import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/products_service.dart';
import '../ui/app_shell.dart';

class ExpiryAlertsScreen extends StatefulWidget {
  const ExpiryAlertsScreen({super.key});

  @override
  State<ExpiryAlertsScreen> createState() => _ExpiryAlertsScreenState();
}

class _ExpiryAlertsScreenState extends State<ExpiryAlertsScreen> {
  List<Map<String, dynamic>> _products = [];
  bool _loading = true;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final decoded = await ProductsService.getProducts();
    final now = DateTime.now();

    _products = decoded.map<Map<String, dynamic>>((item) {
      DateTime? expiry;
      final expiryStr = item['expiryDate'] as String?;
      if (expiryStr != null) {
        try {
          expiry = DateTime.parse(expiryStr);
        } catch (_) {
          expiry = null;
        }
      }
      final daysLeft = expiry != null ? expiry.difference(now).inDays : null;
      return {
        ...item,
        'expiryDateTime': expiry,
        'daysLeft': daysLeft,
      };
    }).toList();

    _products.sort((a, b) {
      final aDays = a['daysLeft'] as int?;
      final bDays = b['daysLeft'] as int?;
      final aVal = aDays ?? 9999;
      final bVal = bDays ?? 9999;
      return aVal.compareTo(bVal);
    });

    setState(() {
      _loading = false;
    });
  }

  List<Map<String, dynamic>> get _expiredProducts =>
      _products.where((p) {
        final d = p['daysLeft'] as int?;
        return d != null && d < 0;
      }).toList();

  List<Map<String, dynamic>> get _soonProducts =>
      _products.where((p) {
        final d = p['daysLeft'] as int?;
        return d != null && d >= 0 && d <= 3;
      }).toList();

  int get _totalItems => _products.length;
  int get _totalExpired => _expiredProducts.length;
  int get _totalSoon => _soonProducts.length;

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const AppShell(
        child: Center(
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor:
                AlwaysStoppedAnimation<Color>(Color(0xFF22D3EE)),
          ),
        ),
      );
    }

    if (_products.isEmpty) {
      return AppShell(
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: const Color(0xFF020617).withOpacity(0.95),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white12),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.check_circle_outline,
                  color: Color(0xFF22C55E),
                  size: 32,
                ),
                const SizedBox(height: 12),
                Text(
                  'No expiry alerts. Everything looks fresh.',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'You\'re managing your food well.',
                  style: GoogleFonts.poppins(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return AppShell(
      child: RefreshIndicator(
        onRefresh: _loadProducts,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.warning_amber_outlined,
                              color: Color(0xFFF97316), size: 22),
                          const SizedBox(width: 8),
                          Text(
                            'Expiry Alerts',
                            style: GoogleFonts.spaceGrotesk(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Items that need your attention.',
                        style: GoogleFonts.poppins(
                          color: Colors.white70,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  DropdownButtonHideUnderline(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF020617),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: DropdownButton<String>(
                        value: _filter,
                        dropdownColor: const Color(0xFF020617),
                        icon: const Icon(Icons.keyboard_arrow_down,
                            color: Colors.white70),
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'All',
                            child: Text('All'),
                          ),
                          DropdownMenuItem(
                            value: 'Expiring Soon',
                            child: Text('Expiring Soon'),
                          ),
                          DropdownMenuItem(
                            value: 'Expired',
                            child: Text('Expired'),
                          ),
                        ],
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _filter = v);
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Row(
                children: [
                  Expanded(
                    child: _summaryCard(
                      label: 'Total Items',
                      value: _totalItems.toString(),
                      color: const Color(0xFF22D3EE),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _summaryCard(
                      label: 'Expiring in 3 Days',
                      value: _totalSoon.toString(),
                      color: const Color(0xFFF97316),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _summaryCard(
                      label: 'Already Expired',
                      value: _totalExpired.toString(),
                      color: const Color(0xFFFB7185),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 40),
              if (_expiredProducts.isNotEmpty &&
                  (_filter == 'All' || _filter == 'Expired'))
                _buildExpiredSection(_expiredProducts),
              if (_expiredProducts.isNotEmpty &&
                  (_filter == 'All' || _filter == 'Expired'))
                const SizedBox(height: 40),
              if (_soonProducts.isNotEmpty &&
                  (_filter == 'All' || _filter == 'Expiring Soon'))
                _buildSoonSection(_soonProducts),
              if (_soonProducts.isNotEmpty &&
                  (_filter == 'All' || _filter == 'Expiring Soon'))
                const SizedBox(height: 40),
              if (_filter == 'All') _buildTableSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryCard({
    required String label,
    required String value,
    required Color color,
  }) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 250),
      tween: Tween<double>(begin: 0.96, end: 1.0),
      builder: (context, scale, child) {
        return MouseRegion(
          onEnter: (_) {},
          child: Transform.scale(scale: scale, child: child),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        decoration: BoxDecoration(
          color: const Color(0xFF020617).withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.6), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.35),
              blurRadius: 20,
              spreadRadius: -8,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpiredSection(List<Map<String, dynamic>> items) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF7F1D1D).withOpacity(0.9),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFFCA5A5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.error_outline,
                  color: Color(0xFFFECACA), size: 22),
              const SizedBox(width: 8),
              Text(
                'Expired Items',
                style: GoogleFonts.spaceGrotesk(
                  color: const Color(0xFFFECACA),
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 2,
            width: 80,
            margin: const EdgeInsets.only(top: 4, bottom: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFCA5A5), Colors.transparent],
              ),
            ),
          ),
          ...items.map((p) {
            final name = (p['product_name'] ?? 'Unknown').toString();
            final expiry = p['expiryDateTime'] as DateTime?;
            final daysLeft = p['daysLeft'] as int?;
            final daysAgo = daysLeft != null ? -daysLeft : null;
            final expiryText = expiry == null
                ? 'Unknown expiry'
                : '${expiry.day}/${expiry.month}/${expiry.year}';
            final subtitle = daysAgo == null
                ? 'Expired'
                : 'Expired $daysAgo day${daysAgo == 1 ? '' : 's'} ago';
            return _alertItemCard(
              name: name,
              expiryText: expiryText,
              badgeLabel: 'Expired',
              badgeColor: const Color(0xFFEF4444),
              subtitle: subtitle,
            );
          }),
        ],
      ),
    );
  }

  Widget _buildSoonSection(List<Map<String, dynamic>> items) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF451A03).withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF97316)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Urgent (0–3 days)',
            style: GoogleFonts.spaceGrotesk(
              color: const Color(0xFFFBD38D),
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Container(
            height: 2,
            width: 120,
            margin: const EdgeInsets.only(top: 2, bottom: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFF97316), Colors.transparent],
              ),
            ),
          ),
          ...items.map((p) {
            final name = (p['product_name'] ?? 'Unknown').toString();
            final expiry = p['expiryDateTime'] as DateTime?;
            final daysLeft = p['daysLeft'] as int?;
            final expiryText = expiry == null
                ? 'Unknown expiry'
                : '${expiry.day}/${expiry.month}/${expiry.year}';
            String label;
            if (daysLeft == null) {
              label = 'Soon';
            } else if (daysLeft == 0) {
              label = 'Today';
            } else if (daysLeft == 1) {
              label = '1 Day Left';
            } else {
              label = '$daysLeft Days Left';
            }
            final badgeColor = daysLeft != null && daysLeft <= 1
                ? const Color(0xFFEF4444)
                : const Color(0xFFF97316);
            return _alertItemCard(
              name: name,
              expiryText: expiryText,
              badgeLabel: label,
              badgeColor: badgeColor,
              subtitle: 'Expires soon',
            );
          }),
        ],
      ),
    );
  }

  Widget _alertItemCard({
    required String name,
    required String expiryText,
    required String badgeLabel,
    required Color badgeColor,
    required String subtitle,
  }) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 200),
      tween: Tween<double>(begin: 1.0, end: 1.0),
      builder: (context, value, child) {
        return MouseRegion(
          onEnter: (_) {},
          child: Transform.scale(scale: value, child: child),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    expiryText,
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.poppins(
                      color: Colors.white60,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 5,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                color: badgeColor.withOpacity(0.15),
                boxShadow: [
                  BoxShadow(
                    color: badgeColor.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -6,
                  ),
                ],
              ),
              child: Text(
                badgeLabel,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTableSection() {
    final sorted = List<Map<String, dynamic>>.from(_products);
    sorted.sort((a, b) {
      final ad = a['daysLeft'] as int?;
      final bd = b['daysLeft'] as int?;
      final av = ad ?? 9999;
      final bv = bd ?? 9999;
      return av.compareTo(bv);
    });

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF020617).withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'All Products',
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _tableHeader('Product', flex: 4),
              _tableHeader('Expiry Date', flex: 3),
              _tableHeader('Days Left', flex: 2, alignEnd: true),
              _tableHeader('Status', flex: 2, alignEnd: true),
            ],
          ),
          const Divider(color: Colors.white12, height: 16),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: sorted.length,
            itemBuilder: (context, index) {
              final p = sorted[index];
              final name =
                  (p['product_name'] ?? 'Unknown').toString();
              final expiry = p['expiryDateTime'] as DateTime?;
              final daysLeft = p['daysLeft'] as int?;
              final status = _statusFor(daysLeft);
              final expiryText = expiry == null
                  ? '—'
                  : '${expiry.day}/${expiry.month}/${expiry.year}';

              return Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 6, horizontal: 0),
                child: Row(
                  children: [
                    Expanded(
                      flex: 4,
                      child: Text(
                        name,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        expiryText,
                        style: GoogleFonts.poppins(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          daysLeft?.toString() ?? '—',
                          style: GoogleFonts.poppins(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(999),
                            color: status.color.withOpacity(0.15),
                          ),
                          child: Text(
                            status.label,
                            style: GoogleFonts.poppins(
                              color: status.color,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _tableHeader(String text,
      {required int flex, bool alignEnd = false}) {
    return Expanded(
      flex: flex,
      child: Align(
        alignment:
            alignEnd ? Alignment.centerRight : Alignment.centerLeft,
        child: Text(
          text,
          style: GoogleFonts.poppins(
            color: Colors.white54,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  _Status _statusFor(int? daysLeft) {
    if (daysLeft == null) {
      return const _Status('Unknown', Colors.grey);
    }
    if (daysLeft < 0) {
      return const _Status('Expired', Color(0xFFEF4444)); // Red
    }
    if (daysLeft <= 3) {
      return const _Status('Expiring Soon', Color(0xFFF97316)); // Orange
    }
    if (daysLeft <= 7) {
      return const _Status('Use Soon', Color(0xFFEAB308)); // Yellow 4–7 days
    }
    return const _Status('Safe', Color(0xFF22C55E)); // Green
  }
}

class _Status {
  final String label;
  final Color color;

  const _Status(this.label, this.color);
}

