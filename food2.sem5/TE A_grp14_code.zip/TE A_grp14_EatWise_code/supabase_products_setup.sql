-- Run this in your Supabase project: SQL Editor → New query → paste → Run

-- Table: products (one row per product per user)
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_name text not null,
  barcode text default '',
  expiry_date timestamptz,
  created_at timestamptz default now()
);

-- Index for fast lookups by user
create index if not exists products_user_id_idx on public.products (user_id);

-- RLS: users can only see and manage their own products
alter table public.products enable row level security;

drop policy if exists "Users can read own products" on public.products;
create policy "Users can read own products"
  on public.products for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own products" on public.products;
create policy "Users can insert own products"
  on public.products for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own products" on public.products;
create policy "Users can update own products"
  on public.products for update
  using (auth.uid() = user_id);

drop policy if exists "Users can delete own products" on public.products;
create policy "Users can delete own products"
  on public.products for delete
  using (auth.uid() = user_id);
